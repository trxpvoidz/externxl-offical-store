███████  ██████ ██      ██ ██████  ████████ ██ ██   ██
██      ██      ██      ██ ██   ██    ██    ██  ██ ██
█████   ██      ██      ██ ██████     ██    ██   ███
██      ██      ██      ██ ██         ██    ██  ██ ██
███████  ██████ ███████ ██ ██         ██    ██ ██   ██

˚₊‧ ꒰ა👑founded by trxpvoidz and DqrkEgirl👑໒꒱ ‧₊˚

```
  ⬇want more skins/capes? join discord here!⬇

       http://discord.gg/3x3M289anm
```

ৡ‿◟ 𖣯 𓂃 𝘛𝘳𝘢𝘱𝘱𝘦𝘥 𝘪𝘯 𝘋𝘢𝘮𝘯𝘢𝘵𝘪𝘰𝘯 ͡𓈒𝜗𐦶
   𝔱𝔯𝔵𝔭 ୨୧ ˖ ࣪ . \ trapped
　‹𝟹 =͟͟͞♡ ꕀ . 𝘛𝘳𝘹𝘱 \ 𝘝𝘰𝘪𝘥𝘻

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
COPYRIGHT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This Minecraft: Bedrock Edition 4D Skin Pack and its
original skins, textures, 4D models, geometry, capes,
and other included assets belong to their respective
creators and the Ecliptix community.

DO NOT:

• Re-upload or redistribute this pack without permission.
• Sell, monetize, or profit from this pack or its assets.
• Claim this pack or its contents as your own.
• Reuse our 4D textures, models, geometry, skins, or
capes in another project without permission.
• Upload, share, or distribute individual assets from
this pack without permission.
• Use our assets in another skin pack or project that
is being monetized.
• Remove our credits and redistribute the work.

If you want to use any of our assets, ASK FIRST.

Skin Pack made by

* trxpvoidz
* anna
* a6wwp
* qm8w
* Yuta
* jeraoi
* 8quart

© 2026 Ecliptix / respective creators.
All rights reserved.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
